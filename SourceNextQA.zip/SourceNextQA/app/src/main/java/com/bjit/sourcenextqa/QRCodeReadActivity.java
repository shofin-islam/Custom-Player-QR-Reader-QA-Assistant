package com.bjit.sourcenextqa;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

/**
 * An example full-screen activity that shows and hides the system UI (i.e.
 * status bar and navigation/system bar) with user interaction.
 */
public class QRCodeReadActivity extends AppCompatActivity {
    public static TextView resultView;
    private Button scanButton;
    private ImageButton backFromScan;
    public ArrayList<String> qrCodeData = new ArrayList<String>();
    String TAG = "SafiulQRCodeReadActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qrcode_read);
        resultView= findViewById(R.id.resultView);
        scanButton = findViewById(R.id.scanButton);
        backFromScan= findViewById(R.id.backFromScan);
        backFromScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        scanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),ScannerActivity.class);
                startActivityForResult(intent,101);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        SharedPreferences sharedPreferences = getSharedPreferences("SharedPref",MODE_PRIVATE);
        Gson gson = new Gson();

        if(resultCode == 101){
            String qrCode = data.getExtras().getString("qrCode");
            qrCodeData.add(qrCode);
            String s = "Scan Information :";
            for (int x=qrCodeData.size()-1; x>=0; x--) {
                int sl = x+1; s += "\n "+sl+". " + qrCodeData.get(x);}

            ArrayList<String> finalData = new ArrayList<>();
                try {
                    String historyData = sharedPreferences.getString("History",null);
                    Log.d(TAG, "onActivityResult: "+historyData);
                    Type type = new TypeToken<ArrayList<String>>() {}.getType();
                    ArrayList<String> BQInfosOld = gson.fromJson(historyData,type);
                    finalData.addAll(BQInfosOld);
                }catch (Exception e){

                }
                finalData.add(qrCode);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                String newInfo = gson.toJson(finalData);
                editor.putString("History",newInfo);
                editor.apply();
            resultView.setText(s);
        }
    }
}
