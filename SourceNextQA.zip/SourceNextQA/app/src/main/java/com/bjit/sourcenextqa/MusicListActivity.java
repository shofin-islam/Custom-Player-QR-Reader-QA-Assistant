package com.bjit.sourcenextqa;

import android.app.Activity;
import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Environment;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.SimpleAdapter;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

public class MusicListActivity extends Activity {

    public ArrayList<HashMap<String, String>> songsList = new ArrayList<HashMap<String, String>>();
    String TAG = "Safiul_MusicPlayerActivity";
    private SearchView mySearchView;
    private CustomAdapterMusic customAdapterMusic;
    private ListView customList;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music_list);
        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        mySearchView = findViewById(R.id.searchViewId);
        customList = findViewById(R.id.list);
        ArrayList<HashMap<String, String>> songsListData = new ArrayList<HashMap<String, String>>();
        SongsManager plm = new SongsManager();
        this.songsList = plm.getPlayList();
        for (int i = 0; i < songsList.size(); i++) {
            HashMap<String, String> song = songsList.get(i);
            songsListData.add(song);
            Log.d(TAG, "onCreate: songs id main : "+songsList.get(i).get("id"));
        }
        // Adding menuItems to ListView
        customAdapterMusic = new CustomAdapterMusic(this,songsListData);
        customList.setAdapter(customAdapterMusic);
        customList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // getting listitem index
                int songIndex = position;
                // Starting new intent
                Intent in = new Intent(getApplicationContext(), MusicPlayerActivity.class);
                // Sending songIndex to PlayerActivity
                in.putExtra("songIndex", songIndex);
               startActivity(in);
            }
        });

        mySearchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                ArrayList<HashMap<String, String>> songsCollection = new ArrayList<HashMap<String, String>>();
                final ArrayList<HashMap<String, String>> filteredSongs = new ArrayList<HashMap<String, String>>();
                songsCollection = new SongsManager().getPlayList();
                for (int i = 0; i < songsCollection.size(); i++) {
                    String songsName = songsCollection.get(i).get("songTitle");
                    if (songsName.toLowerCase().contains(newText)){
                        filteredSongs.add(songsCollection.get(i));
                    }else{}
                    Log.d(TAG, "onTextChanged: songs id filter : "+songsCollection.get(i).get("id"));
                }
                CustomAdapterMusic customAdapterMusic2 = new CustomAdapterMusic(getApplicationContext(),filteredSongs);
                customList.setAdapter(customAdapterMusic2);
                customList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        String songIndex = filteredSongs.get(position).get("id");
                        // Starting new intent
                        Intent in = new Intent(getApplicationContext(), MusicPlayerActivity.class);
                        // Sending songIndex to PlayerActivity
                        in.putExtra("songIndex",Integer. parseInt(songIndex) );
                        startActivity(in);
                    }
                });
                return false;
            }
        });
//        mySearchView.addTextChangedListener(new TextWatcher() {
//            @Override
//            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
//
//            }
//
//            @Override
//            public void onTextChanged(CharSequence s, int start, int before, int count) {
//                if (s.length()!=0){
//                    ArrayList<HashMap<String, String>> songsCollection = new ArrayList<HashMap<String, String>>();
//                    final ArrayList<HashMap<String, String>> filteredSongs = new ArrayList<HashMap<String, String>>();
//                    songsCollection = new SongsManager().getPlayList();
//                    for (int i = 0; i < songsCollection.size(); i++) {
//                        String songsName = songsCollection.get(i).get("songTitle");
//                        if (songsName.toLowerCase().contains(s)){
//                            filteredSongs.add(songsCollection.get(i));
//                        }else{}
//                        Log.d(TAG, "onTextChanged: songs id filter : "+songsCollection.get(i).get("id"));
//                    }
//                    CustomAdapterMusic customAdapterMusic2 = new CustomAdapterMusic(getApplicationContext(),filteredSongs);
//                    customList.setAdapter(customAdapterMusic2);
//                    customList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//                        @Override
//                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                            String songIndex = filteredSongs.get(position).get("id");
//                            // Starting new intent
//                            Intent in = new Intent(getApplicationContext(), MusicPlayerActivity.class);
//                            // Sending songIndex to PlayerActivity
//                            in.putExtra("songIndex",Integer. parseInt(songIndex) );
//                            startActivity(in);
//                        }
//                    });
//                }
//            }
//
//            @Override
//            public void afterTextChanged(Editable s) {
//
//            }
//        });
    }

}
