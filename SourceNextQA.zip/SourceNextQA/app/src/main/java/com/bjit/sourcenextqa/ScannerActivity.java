package com.bjit.sourcenextqa;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.util.Linkify;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import com.google.zxing.Result;

import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class ScannerActivity extends Activity implements ZXingScannerView.ResultHandler {

    ZXingScannerView scannerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        scannerView = new ZXingScannerView(this);
        setContentView(scannerView);
        scannerView.setAutoFocus(true);
        scannerView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
//                if (scannerView.getFlash()) {
//                    scannerView.setFlash(false);
//                } else {
//                    scannerView.setFlash(true);
//                }
                scannerView.clearFocus();
                scannerView.setAutoFocus(true);
                scannerView.setTouchscreenBlocksFocus(true);
                Toast.makeText(getApplicationContext(), "Focus Request", Toast.LENGTH_SHORT).show();
//           Toast.makeText(getApplicationContext(),"On   touch", Toast.LENGTH_SHORT).show();
                return true;
            }
        });
    }

    @Override
    public void handleResult(Result result) {
//        if (result.getText().contains("http")){
//            QRCodeReadActivity.resultView.setAutoLinkMask(Linkify.WEB_URLS);
//            QRCodeReadActivity.resultView.setLinksClickable(true);
//        }else { }
//        QRCodeReadActivity.resultView.setText(result.getText());
//        QRCodeReadActivity.resultView.setTextColor(Color.parseColor("#f7347a"));
//        qrCodeData.add(result.getText());

//        Log.d("QRCode", "handleResult: "+result.getText());
        // Starting new intent
        Intent in = new Intent(getApplicationContext(),QRCodeReadActivity.class);
        in.putExtra("qrCode", result.getText());
        setResult(101, in);
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        scannerView.setResultHandler(this);
        scannerView.startCamera();
    }

    @Override
    protected void onPause() {
        super.onPause();
        scannerView.stopCamera();
    }
}

