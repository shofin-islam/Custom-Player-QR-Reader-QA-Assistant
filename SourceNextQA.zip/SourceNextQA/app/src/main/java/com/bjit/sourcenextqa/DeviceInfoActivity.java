package com.bjit.sourcenextqa;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class DeviceInfoActivity extends AppCompatActivity {
    String TAG = "getDeviceSuperInfo";
    TextView resultsView;
    TextView apkInformation;
    ImageButton backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device_info);
        resultsView = findViewById(R.id.deviceInfoResults);
        resultsView.setText(getDeviceSuperInfo());
        apkInformation=findViewById(R.id.apkInfoResults);
        apkInformation.setText(getApkInfo());
        backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    private String getApkInfo() {
        try {
            String s = "APK Information:";
            s += "\n - Package Name:\n"      + "   "+getPackageName();
            s += "\n - Main Activity Name:\n"    + "   MainActivity";
            return s;
        } catch (Exception e) {
            return "Somethings Wrong!!";
        }
    }

    private String getDeviceSuperInfo() {
        try {
            String s = "Device Information:";
            s += "\n - OS Version: "      + System.getProperty("os.version");
            s += "\n - OS API Level: "    + android.os.Build.VERSION.SDK_INT;
            s += "\n - Device: "          + android.os.Build.DEVICE;
            s += "\n - Model: "           + android.os.Build.MODEL;
            s += "\n - RELEASE: "         + android.os.Build.VERSION.RELEASE;
            s += "\n - SERIAL: "          + android.os.Build.SERIAL;
            s += "\n - BRAND: "           + android.os.Build.BRAND;
//            s += "\n - ANDROID_ID: "      + Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
            s += "\n - MANUFACTURER: "    + android.os.Build.MANUFACTURER;
//            Log.i(TAG + " | Device Info > ", s);

            return s;
        } catch (Exception e) {
//            Log.e(TAG, "Error getting Device INFO");
            return "Somethings Wrong!!";
        }

    }
}
