package com.bjit.sourcenextqa;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private Button musicPlayer,QRReader,deviceInfoButton,historyButton;
    ImageButton backButton;
    String TAG ="Safiul";
    public static SharedPreferences preferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        preferences = getSharedPreferences( getPackageName() + "_preferences", MODE_PRIVATE);
        String[] x = getExternalFilesDir("/").getPath().split("[/]");
        String rootStorage="/";
        for (int i=1; i<x.length; i++){
//            Log.d(TAG, "onCreate: "+x[i]);
            if (x[i].toString().contains("Android")){
                i=x.length;
            }else{
                rootStorage= rootStorage+x[i]+"/";
            }
        }
//        Log.d(TAG, "onCreate: Final Storage "+rootStorage);
        PrefHelper prefHelper = new PrefHelper();
        prefHelper.setRootDir(rootStorage);
        backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ExitApplication();
            }
        });
        musicPlayer = findViewById(R.id.musicPlayerId);
        QRReader = findViewById(R.id.barCodeReader);
        historyButton = findViewById(R.id.barCodeHistory);
        historyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),QRCodeHistory.class);
                startActivity(intent);
            }
        });
        deviceInfoButton = findViewById(R.id.deviceInfoButton);
        musicPlayer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),MusicListActivity.class);
                startActivity(intent);
            }
        });

        QRReader.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),QRCodeReadActivity.class);
                startActivity(intent);
            }
        });
        deviceInfoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),DeviceInfoActivity.class);
                startActivity(intent);
            }
        });
    }

    private void ExitApplication() {
        // alertdialog for exit the app
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);

// set the title of the Alert Dialog
        alertDialogBuilder.setTitle("Exit");

// set dialog message
        alertDialogBuilder.setMessage("Are you sure?");
        alertDialogBuilder.setCancelable(false);
        alertDialogBuilder.setPositiveButton("Exit",new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // what to do if YES is tapped
                finishAffinity();
                System.exit(0);
            }
        }). setNegativeButton("Cancel",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // code to do on NO tapped
                        dialog.cancel();
                    }
                });
        AlertDialog alertDialog = alertDialogBuilder.create();

        alertDialog.show();
    }
}
