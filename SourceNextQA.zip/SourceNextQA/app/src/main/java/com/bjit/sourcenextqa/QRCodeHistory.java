package com.bjit.sourcenextqa;

import android.content.SharedPreferences;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class QRCodeHistory extends AppCompatActivity {
    Button clearHistoryButton;
    ImageButton backButton;
    TextView historyView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qrcode_history);
        historyView = findViewById(R.id.historyView);
        clearHistoryButton=findViewById(R.id.clearHistoryButton);
        backButton= findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        clearHistoryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    SharedPreferences sharedPreferencesClear = getSharedPreferences("SharedPref",MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferencesClear.edit();
                    editor.clear();
                    editor.apply();
                    historyView.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                    historyView.setPadding(0,30,0,30);
                    historyView.setText("Clear Successfully");
//                    Toast.makeText(getApplicationContext(),"Clear Successfully",Toast.LENGTH_SHORT).show();
                }catch (Exception e){
                    Log.d("HistoryExceptionsClear", "onClick: "+e);
                }
            }
        });
        String s = "";
        try {
            Gson gson = new Gson();
            SharedPreferences sharedPreferencesLoad = getSharedPreferences("SharedPref",MODE_PRIVATE);
            String historyData = sharedPreferencesLoad.getString("History",null);
            Type type = new TypeToken<ArrayList<String>>() {}.getType();
            ArrayList<String> BQInfos = gson.fromJson(historyData,type);
            Log.d("History", "onCreate: size "+BQInfos.size());
            s= "Scan Information:";
            if (BQInfos.size()>0){
                for (int x=BQInfos.size()-1; x>=0; x--) {
                    int sl = x+1;
                    s += "\n "+sl+". " + BQInfos.get(x);
                }
            }
        }catch (Exception e){
            Log.d("History", "Exceptions "+e);
        }
        historyView.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_START);
        historyView.setText(s);
    }

}
