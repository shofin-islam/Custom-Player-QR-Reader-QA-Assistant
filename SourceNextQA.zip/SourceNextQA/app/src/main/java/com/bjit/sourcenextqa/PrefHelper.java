package com.bjit.sourcenextqa;

public class PrefHelper {
    final public static String KEY_ROOT_DIR = "/sdcard/";
    public static void  setRootDir(String value){
        MainActivity.preferences.edit().putString(KEY_ROOT_DIR,value).commit();
    }
    public static String  getRootDir(){
       return MainActivity.preferences.getString(KEY_ROOT_DIR,"/sdcard/");
    }
}
